## Main Credits:

- [Pharap](https://github.com/Pharap) - main programmer

## Extra special thanks to:

- [bakagamedev](https://github.com/bakagamedev) - extra-handy duck
- [filmote](https://github.com/filmote) - testing and debugging
- [eried](https://github.com/eried) - testing and debugging

## Special mentions:

- crait
- Bergasms
