Source to build the Cathy3K bootloaders can be found at:

https://github.com/MrBlinky/cathy3k